﻿namespace BlazorMovieApp.Models
{
    public class MovieSearchInfo
    {
        public string Poster_path { get; set; }
        public string Release_date { get; set; }
        public string Title { get; set; }
       
    }

}
